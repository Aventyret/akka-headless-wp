# Akka Headless WP

This plugin enables running headless Wordpress will the full power
of the Wordpress block editor.

These environment variables are used by the plugin:

```
AKKA_CMS_COOKIE_NAME
AKKA_CMS_COOKIE_PATH
AKKA_CMS_MEDIA_BUCKET_HOSTNAME
AKKA_CMS_MEDIA_BUCKET_PORT
AKKA_CMS_MEDIA_BUCKET_PROTOCOL
AKKA_CMS_URL_INTERNAL
AKKA_FRONTEND_FLUSH_CACHE_KEY
AKKA_FRONTEND_URL
AKKA_FRONTEND_URL_INTERNAL
```
