<?php
function akka_headless_wp_create_acf_fields() {
  if( function_exists('acf_add_local_field_group') ):
  endif;
}
